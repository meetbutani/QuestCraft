import React from 'react'
import DefaultLayout from '../../layout/DefaultLayout'

const Dashboard = () => {
    return (
        <DefaultLayout>
            <div>Dashboard</div>
        </DefaultLayout>
    )
}

export default Dashboard